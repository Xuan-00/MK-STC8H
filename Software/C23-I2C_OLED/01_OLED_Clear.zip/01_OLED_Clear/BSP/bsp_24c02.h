#ifndef	__BSP_24C02_H__
#define	__BSP_24C02_H__

#include "type_def.h"


void M24C02_Init(void);
void M24C02_WriteByte(u8 addr, u8 dat);
void M24C02_WriteNBytes(u8 addr, u8 *dat, u8 len);
u8 M24C02_ReadByte(u8 addr);
void M24C02_ReadNBytes(u8 addr, u8 *p, u8 len);

#endif // bsp_24c02.h
