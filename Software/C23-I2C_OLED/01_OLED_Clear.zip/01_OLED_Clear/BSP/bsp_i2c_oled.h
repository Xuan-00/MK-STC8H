#ifndef	__BSP_I2C_OLED_H__
#define	__BSP_I2C_OLED_H__

#include "type_def.h"

void I2C_OLED_Init(void);
void OLED_Init(void);

#endif // bsp_i2c_oled.h
