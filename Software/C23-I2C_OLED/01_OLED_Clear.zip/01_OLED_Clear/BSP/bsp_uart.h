#ifndef		__BSP_UART_H__
#define		__BSP_UART_H__

#include "type_def.h"


extern u8 UART1_RxFlag;

void UART1_Init(void);
void UART1_RxProcess(void);
void UART1_SendBuffer(u8 *buf, u8 len);

#endif //bsp_uart.h

